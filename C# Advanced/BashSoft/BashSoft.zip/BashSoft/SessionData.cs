﻿using System.IO;

namespace BashSoft
{
    public class SessionData
    {
        public static string currentPath = Directory.GetCurrentDirectory();
    }
}